from pymongo import MongoClient

# --- CONFIGURATION ---
MONGO_URI = "mongodb+srv://christischoeman_db_user:1234@novacluster.1re1a4e.mongodb.net/"
DATABASE_NAME = "Nova_Analytix"
COLLECTION_NAME = "Customer_flat_step2"

# --- CONNECT & CLEAN ---
try:
    client = MongoClient(MONGO_URI)
    db = client[DATABASE_NAME]
    customer_coll = db[COLLECTION_NAME]
    
    print(f"Starting cleanup on {COLLECTION_NAME}...")

    # Query 1: Find all documents where the field is an empty string or null
    update_result = customer_coll.update_many(
        {
            "age_FIN_PERIOD": { 
                "$in": ["", None]  # Finds empty strings or nulls
            }
        },
        {
            "$set": {
                "age_FIN_PERIOD": "N/A"  # Set to a guaranteed non-date string
            }
        }
    )

    print(f"Clean up complete. {update_result.modified_count} documents updated.")

except Exception as e:
    print(f"An error occurred during cleanup: {e}")

finally:
    client.close()