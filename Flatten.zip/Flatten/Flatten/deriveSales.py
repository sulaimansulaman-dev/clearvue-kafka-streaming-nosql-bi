import time
from pymongo import MongoClient

# --- connect ---
client = MongoClient("mongodb+srv://christischoeman_db_user:1234@novacluster.1re1a4e.mongodb.net/")
db = client["Nova_Analytix"]
sales_flat = db["Sales_flat"]

# --- count and confirm ---
total_docs = sales_flat.estimated_document_count()
print(f"Starting update on {total_docs:,} Sales_flat documents...")

# --- timing start ---
t0 = time.time()

# --- server-side derivation (absolute total) ---
result = sales_flat.update_many(
    {},
    [
        {
            "$set": {
                "line_TOTAL_LINE_PRICE": {
                    "$abs": {
                        "$multiply": [
                            "$line_QUANTITY",
                            "$line_UNIT_SELL_PRICE"
                        ]
                    }
                }
            }
        }
    ]
)

# --- timing end ---
t1 = time.time()

# --- summary ---
print("✅ Update complete!")
print(f"Matched documents : {result.matched_count:,}")
print(f"Modified documents: {result.modified_count:,}")
print(f"Elapsed time      : {t1 - t0:.2f} seconds")
