from pymongo import MongoClient

# 1. Connect to your MongoDB
client = MongoClient("mongodb+srv://christischoeman_db_user:1234@novacluster.1re1a4e.mongodb.net/")
db = client["Nova_Analytix"]
collection = db["Purchases_flat"]

# 2. Loop through documents that need updating
for doc in collection.find():
    quantity = doc.get("lines_QUANTITY")
    unit_cost = doc.get("lines_UNIT_COST_PRICE")

    # 3. Compute derived total cost if both are valid
    if quantity is not None and unit_cost is not None:
        derived_total = quantity * unit_cost

        # 4. Update only if needed (optional optimization)
        if doc.get("lines_TOTAL_LINE_COST") != derived_total:
            collection.update_one(
                {"_id": doc["_id"]},
                {"$set": {"lines_TOTAL_LINE_COST": derived_total}}
            )
            print(f"Updated {doc['_id']}: {derived_total}")
