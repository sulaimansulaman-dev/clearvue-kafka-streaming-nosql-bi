from pymongo import MongoClient
from bson import ObjectId

# Atlas connection
client = MongoClient("mongodb+srv://christischoeman_db_user:1234@novacluster.1re1a4e.mongodb.net/")
db = client["Nova_Analytix"]
customer_coll = db["Customer"]

flat_step1_coll = db["Customer_flat_step1"]
flat_step1_coll.drop()
flat_step2_coll = db["Customer_flat_step2"]
flat_step2_coll.drop()

BATCH_SIZE = 500  # insert in batches of 500 docs

# --- Flatten account_parameters ---
print("Flattening account_parameters...")
batch = []
for i, doc in enumerate(customer_coll.find(), 1):
    if "account_parameters" in doc and doc["account_parameters"]:
        for param in doc["account_parameters"]:
            flat_doc = doc.copy()
            flat_doc["_id"] = ObjectId()
            flat_doc["account_parameters_parameter"] = param.get("PARAMETER")
            flat_doc.pop("account_parameters", None)
            batch.append(flat_doc)
    else:
        flat_doc = doc.copy()
        flat_doc["_id"] = ObjectId()
        flat_doc.pop("account_parameters", None)
        batch.append(flat_doc)

    if len(batch) >= BATCH_SIZE:
        flat_step1_coll.insert_many(batch)
        batch = []
    if i % 100 == 0:
        print(f"Processed {i} Customer docs for account_parameters")

# Insert any remaining docs
if batch:
    flat_step1_coll.insert_many(batch)
print("Finished flattening account_parameters.")

# --- Flatten age_analysis ---
print("Flattening age_analysis...")
batch = []
for i, doc in enumerate(flat_step1_coll.find(), 1):
    if "age_analysis" in doc and doc["age_analysis"]:
        for period in doc["age_analysis"]:
            flat_doc = doc.copy()
            flat_doc["_id"] = ObjectId()
            flat_doc.pop("age_analysis", None)
            for k, v in period.items():
                flat_doc[f"age_{k}"] = v
            batch.append(flat_doc)
    else:
        flat_doc = doc.copy()
        flat_doc["_id"] = ObjectId()
        flat_doc.pop("age_analysis", None)
        batch.append(flat_doc)

    if len(batch) >= BATCH_SIZE:
        flat_step2_coll.insert_many(batch)
        batch = []
    if i % 100 == 0:
        print(f"Processed {i} docs from Customer_flat_step1 for age_analysis")

# Insert any remaining docs
if batch:
    flat_step2_coll.insert_many(batch)

print("Finished flattening age_analysis.")
count = flat_step2_coll.count_documents({})
print(f"Total documents in Customer_flat_step2: {count}")
print("Sample document:")
print(flat_step2_coll.find_one())
