from pymongo import MongoClient
from bson import ObjectId

# Atlas connection
client = MongoClient("mongodb+srv://christischoeman_db_user:1234@novacluster.1re1a4e.mongodb.net/")
db = client["Nova_Analytix"]
payments_coll = db["Payments"]

flat_payments_coll = db["Payments_flat"]
flat_payments_coll.drop()

BATCH_SIZE = 500
batch = []

print("Flattening Payments...")

for i, doc in enumerate(payments_coll.find(), 1):
    if "lines" in doc and doc["lines"]:
        for line in doc["lines"]:
            flat_doc = doc.copy()
            flat_doc["_id"] = ObjectId()
            flat_doc.pop("lines", None)
            # Promote all keys from the line
            for k, v in line.items():
                flat_doc[f"line_{k}"] = v
            batch.append(flat_doc)
    else:
        flat_doc = doc.copy()
        flat_doc["_id"] = ObjectId()
        flat_doc.pop("lines", None)
        batch.append(flat_doc)

    if len(batch) >= BATCH_SIZE:
        flat_payments_coll.insert_many(batch)
        batch = []

    if i % 100 == 0:
        print(f"Processed {i} Payment docs")

# Insert any remaining docs
if batch:
    flat_payments_coll.insert_many(batch)

print("Finished flattening Payments.")
count = flat_payments_coll.count_documents({})
print(f"Total documents in Payments_flat: {count}")
print("Sample document:")
print(flat_payments_coll.find_one())
