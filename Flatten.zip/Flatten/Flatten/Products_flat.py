from pymongo import MongoClient
from bson import ObjectId

# Atlas connection
client = MongoClient("mongodb+srv://christischoeman_db_user:1234@novacluster.1re1a4e.mongodb.net/")
db = client["Nova_Analytix"]
products_coll = db["Products"]

flat_products_coll = db["Products_flat"]
flat_products_coll.drop()

BATCH_SIZE = 500
batch = []

print("Flattening Products...")

for i, doc in enumerate(products_coll.find(), 1):
    if "styles" in doc and doc["styles"]:
        for style in doc["styles"]:
            flat_doc = doc.copy()
            flat_doc["_id"] = ObjectId()
            flat_doc.pop("styles", None)
            # Promote all keys from the style
            for k, v in style.items():
                flat_doc[f"style_{k}"] = v
            batch.append(flat_doc)
    else:
        flat_doc = doc.copy()
        flat_doc["_id"] = ObjectId()
        flat_doc.pop("styles", None)
        batch.append(flat_doc)

    if len(batch) >= BATCH_SIZE:
        flat_products_coll.insert_many(batch)
        batch = []

    if i % 100 == 0:
        print(f"Processed {i} Product docs")

# Insert remaining docs
if batch:
    flat_products_coll.insert_many(batch)

print("Finished flattening Products.")
count = flat_products_coll.count_documents({})
print(f"Total documents in Products_flat: {count}")
print("Sample document:")
print(flat_products_coll.find_one())
