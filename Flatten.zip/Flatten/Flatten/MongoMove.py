import pandas as pd
from pymongo import MongoClient

Mongo_Uri = "mongodb+srv://christischoeman_db_user:1234@novacluster.1re1a4e.mongodb.net/Nova_Analytix"
Excel_File = "Merged.xlsx"

client = MongoClient(Mongo_Uri)
db = client.get_database() #it should give nova analytix

#reading the excel file
xls = pd.ExcelFile(Excel_File)

for sheetName in xls.sheet_names:
    dataFile = pd.read_excel(Excel_File, sheet_name = sheetName)
    data = dataFile.where(pd.notnull(dataFile), None).to_dict(orient = "records")

    collection = db[sheetName]
    if data:
        print(f"\nDropping old data in the collection '{sheetName}'")
        collection.drop()
        collection.insert_many(data)
        print(f"Inserted {len(data)} records into '{sheetName}'")
    else:
        print(f"No data to insert for '{sheetName}'")
print("\n All sheets uploaded")