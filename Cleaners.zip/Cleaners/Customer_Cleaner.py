import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_customers():
    # Input path
    input_file = os.path.join("data", "Project Data", "Customer.xlsx")

    # Read Excel
    df = pd.read_excel(input_file, dtype=str)

    # Strip whitespace
    df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    # Remap category references
    df["CCAT_CODE"] = df["CCAT_CODE"].replace("00", "0")
    df["CCAT_CODE"] = df["CCAT_CODE"].replace("48", "44")

    codes_to_replace = ["15", "17", "22", "23", "24", "26", "35", "38", "8", "9"]
    df["CCAT_CODE"] = df["CCAT_CODE"].replace(codes_to_replace, "10")

    # Ensure numeric columns are numeric
    numeric_columns = ["SETTLE_TERMS", "NORMAL_PAYTERMS", "DISCOUNT", "CREDIT_LIMIT"]
    for col in numeric_columns:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("customers", df)
    producer.close()

    print("✅ Customers data sent to Kafka")


if __name__ == "__main__":
    clean_customers()
