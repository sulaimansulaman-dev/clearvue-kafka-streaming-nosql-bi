import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_purchase_lines():
    # Paths
    input_file = os.path.join("data", "Project Data", "Purchases Lines.xlsx")

    # Read Excel
    df = pd.read_excel(input_file, dtype=str)

    # Trim spaces
    df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    # Convert numeric columns to float
    numeric_cols = ["QUANTITY", "UNIT_COST_PRICE", "TOTAL_LINE_COST"]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("purchase_lines", df)
    producer.close()

    print("✅ Purchase lines data sent to Kafka")


if __name__ == "__main__":
    clean_purchase_lines()
