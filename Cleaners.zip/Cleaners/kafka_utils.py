# kafka_utils.py
from kafka import KafkaProducer
import json
import pandas as pd
import logging

class KafkaDataProducer:
    def __init__(self, bootstrap_servers='localhost:9092'):
        self.bootstrap_servers = bootstrap_servers
        self.producer = None
        self._connect()
    
    def _connect(self):
        """Establish connection to Kafka"""
        try:
            self.producer = KafkaProducer(
                bootstrap_servers=[self.bootstrap_servers],
                value_serializer=lambda x: json.dumps(x, default=str).encode('utf-8'),
                acks='all',
                retries=3
            )
            print(f"✅ Connected to Kafka at {self.bootstrap_servers}")
        except Exception as e:
            print(f"❌ Failed to connect to Kafka: {e}")
            raise
    
    def send_data(self, topic, data, key=None):
        """Send data to Kafka topic"""
        try:
            if isinstance(data, pd.DataFrame):
                # Convert DataFrame to list of dictionaries
                records = data.to_dict('records')
                for record in records:
                    future = self.producer.send(
                        topic=topic,
                        value=record,
                        key=key.encode('utf-8') if key else None
                    )
                    future.get(timeout=10)  # Wait for confirmation
                print(f"✅ Sent {len(records)} records to topic '{topic}'")
            elif isinstance(data, list):
                for record in data:
                    future = self.producer.send(
                        topic=topic,
                        value=record,
                        key=key.encode('utf-8') if key else None
                    )
                    future.get(timeout=10)
                print(f"✅ Sent {len(data)} records to topic '{topic}'")
            else:
                future = self.producer.send(
                    topic=topic,
                    value=data,
                    key=key.encode('utf-8') if key else None
                )
                future.get(timeout=10)
                print(f"✅ Sent 1 record to topic '{topic}'")
                
        except Exception as e:
            print(f"❌ Failed to send data to Kafka: {e}")
            raise
    
    def close(self):
        """Close the producer connection"""
        if self.producer:
            self.producer.flush()
            self.producer.close()
            print("✅ Kafka producer closed")