import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_product_ranges():
    # Input
    input_file = os.path.join("data", "Project Data", "Product Ranges.xlsx")

    # Read Excel
    df = pd.read_excel(input_file, dtype=str)

    df = df.drop_duplicates(subset=["PRAN_DESC"], keep="first")

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("product_ranges", df)
    producer.close()

    print("✅ Product ranges data sent to Kafka")


if __name__ == "__main__":
    clean_product_ranges()
