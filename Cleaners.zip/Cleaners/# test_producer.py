# test_producer_simple.py
from kafka import KafkaProducer
import json

def send_test_data():
    producer = KafkaProducer(
        bootstrap_servers=['localhost:9092'],
        value_serializer=lambda x: json.dumps(x).encode('utf-8')
    )
    
    # Test customer
    customer = {
        "CUSTOMER_NUMBER": "TEST001",
        "CUSTOMER_NAME": "Test Store",
        "CCAT_CODE": "CAT01",
        "REGION_CODE": "REG01",
        "CREDIT_LIMIT": 50000,
        "NORMAL_PAYTERMS": 30
    }
    
    producer.send('customers', customer)
    producer.flush()
    print("✅ Sent test customer data")
    producer.close()

if __name__ == "__main__":
    send_test_data()