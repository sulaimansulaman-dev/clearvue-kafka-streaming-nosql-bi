import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_suppliers():
    # Load file
    file_path = os.path.join("data", "Project Data", "Suppliers.xlsx")
    df = pd.read_excel(file_path)

    # Clean SUPPLIER_CODE
    df["SUPPLIER_CODE"] = df["SUPPLIER_CODE"].astype(str).str.strip().str.upper()
    df["SUPPLIER_CODE"] = df["SUPPLIER_CODE"].replace("999999", "Unknown")

    # Clean numeric columns
    df["NORMAL_PAYTERMS"] = (
        pd.to_numeric(df["NORMAL_PAYTERMS"], errors="coerce").fillna(0).astype(int)
    )
    df["CREDIT_LIMIT"] = (
        pd.to_numeric(df["CREDIT_LIMIT"], errors="coerce").fillna(0).astype(int)
    )

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("suppliers", df)
    producer.close()

    print("✅ Suppliers data sent to Kafka")


if __name__ == "__main__":
    clean_suppliers()
