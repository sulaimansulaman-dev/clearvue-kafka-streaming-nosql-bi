import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_customer_regions():
    # Input path
    input_file = os.path.join("data", "Project Data", "Customer Regions.xlsx")
    # Read the Excel file
    df = pd.read_excel(input_file, dtype={"REGION_CODE": str})

    # Strip whitespace
    df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("customer_regions", df)
    producer.close()

    print("✅ Customer regions data sent to Kafka")


if __name__ == "__main__":
    clean_customer_regions()
