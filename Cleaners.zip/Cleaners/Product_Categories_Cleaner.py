import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_product_categories():
    # Input
    input_file = os.path.join("data", "Project Data", "Product Categories.xlsx")

    # Read Excel
    df = pd.read_excel(input_file, dtype=str)

    # replace 3 with 1 since it was duplicate in product ranges
    df["PRAN_CODE"] = df["PRAN_CODE"].replace(3, 1)

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("product_categories", df)
    producer.close()

    print("✅ Product categories data sent to Kafka")


if __name__ == "__main__":
    clean_product_categories()
