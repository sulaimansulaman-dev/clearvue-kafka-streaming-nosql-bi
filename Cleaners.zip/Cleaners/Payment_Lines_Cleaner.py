import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_payment_lines():
    # Load the file
    file_path = os.path.join("data", "Project Data", "Payment Lines.xlsx")
    df = pd.read_excel(file_path)

    # Strip whitespace from string columns
    str_cols = df.select_dtypes(include="object").columns
    for col in str_cols:
        df[col] = df[col].str.strip()

    # Convert FIN_PERIOD to datetime (first day of that month)
    df["FIN_PERIOD"] = pd.to_datetime(df["FIN_PERIOD"], format="%Y%m", errors="coerce")

    # Convert DEPOSIT_DATE to datetime and keep only the date
    df["DEPOSIT_DATE"] = pd.to_datetime(df["DEPOSIT_DATE"], errors="coerce").dt.date

    # Ensure numeric columns are numeric, without rounding
    num_cols = ["BANK_AMT", "DISCOUNT", "TOT_PAYMENT"]
    for col in num_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("payment_lines", df)
    producer.close()

    print("✅ Payment lines data sent to Kafka")


if __name__ == "__main__":
    clean_payment_lines()
