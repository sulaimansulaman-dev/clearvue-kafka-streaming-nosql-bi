import pandas as pd
import os
from kafka_utils import KafkaDataProducer

def clean_sales_line():
    # Load file
    file_path = os.path.join("data", "Project Data", "Sales Line.xlsx")
    df = pd.read_excel(file_path)
    
    # Clean INVENTORY_CODE
    df['INVENTORY_CODE'] = df['INVENTORY_CODE'].astype(str).str.replace(" ", "").str.upper()
    df['INVENTORY_CODE'] = df['INVENTORY_CODE'].replace("999999", "Unknown")
    
    # Ensure numeric columns are numbers
    numeric_cols = ['QUANTITY', 'UNIT_SELL_PRICE', 'TOTAL_LINE_PRICE', 'LAST_COST']
    df[numeric_cols] = df[numeric_cols].apply(pd.to_numeric, errors='coerce').fillna(0).astype(int)
    
    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data('sales_lines', df)
    producer.close()
    
    print("✅ Sales lines data sent to Kafka")

if __name__ == "__main__":
    clean_sales_line()