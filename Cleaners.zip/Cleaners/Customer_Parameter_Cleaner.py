import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_customer_parameters():
    # Load the table
    file_path = os.path.join("data", "Project Data", "Customer Account Parameters.xlsx")

    df = pd.read_excel(file_path, dtype=str)

    # Clean whitespace and standardize column names
    df.columns = [col.strip() for col in df.columns]
    df["CUSTOMER_NUMBER"] = df["CUSTOMER_NUMBER"].str.strip()
    df["PARAMETER"] = df["PARAMETER"].str.strip()

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("customer_parameters", df)
    producer.close()

    print("✅ Customer parameters data sent to Kafka")


if __name__ == "__main__":
    clean_customer_parameters()
