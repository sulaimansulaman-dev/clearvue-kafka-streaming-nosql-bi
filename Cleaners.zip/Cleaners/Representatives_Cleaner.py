import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_representatives():
    # Paths
    input_file = os.path.join("data", "Project Data", "Representatives.xlsx")

    # Read Excel
    df = pd.read_excel(input_file, dtype=str)

    # Trim spaces and title case for relevant columns only
    for col in ["REP_DESC", "COMM_METHOD"]:
        if col in df.columns:
            df[col] = df[col].apply(lambda x: x.strip() if isinstance(x, str) else x)

    # Standardize numeric column
    if "COMMISSION" in df.columns:
        df["COMMISSION"] = pd.to_numeric(df["COMMISSION"], errors="coerce")

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("representatives", df)
    producer.close()

    print("✅ Representatives data sent to Kafka")


if __name__ == "__main__":
    clean_representatives()
