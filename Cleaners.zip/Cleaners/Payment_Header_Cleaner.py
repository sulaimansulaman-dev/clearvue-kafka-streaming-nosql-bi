import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_payment_header():
    # Input path
    input_file = os.path.join("data", "Project Data", "Payment Header.xlsx")

    # Read Excel
    df = pd.read_excel(input_file, dtype=str)

    # Strip whitespace
    df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("payment_headers", df)
    producer.close()

    print("✅ Payment headers data sent to Kafka")


if __name__ == "__main__":
    clean_payment_header()
