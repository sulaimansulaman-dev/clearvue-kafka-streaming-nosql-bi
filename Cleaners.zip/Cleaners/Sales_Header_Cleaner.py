import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_sales_header():
    # Paths
    original_path = os.path.join("data", "Project Data", "Sales Header.xlsx")

    # Read file
    df = pd.read_excel(original_path)

    # Strip whitespace from all string columns
    for col in df.select_dtypes(include="object"):
        df[col] = df[col].str.strip()

    # Ensure dates are date-only
    df["TRANS_DATE"] = pd.to_datetime(df["TRANS_DATE"]).dt.date

    df["FIN_PERIOD"] = pd.to_datetime(df["FIN_PERIOD"], format="%Y%m", errors="coerce")

    # Remove exact duplicate rows
    df = df.drop_duplicates()

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("sales_headers", df)
    producer.close()

    print("✅ Sales headers data sent to Kafka")


if __name__ == "__main__":
    clean_sales_header()
