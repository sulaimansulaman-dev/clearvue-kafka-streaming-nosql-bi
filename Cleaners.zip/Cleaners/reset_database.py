# reset_database.py
from pymongo import MongoClient

def reset_database():
    print("🔄 RESETTING DATABASE")
    print("=" * 50)
    
    try:
        client = MongoClient('mongodb://localhost:27017/')
        
        # Drop the problematic database
        client.drop_database('clearvue_sales')
        print("✅ Dropped clearvue_sales database")
        
        # Create our temp database
        db_temp = client['clearvue_data_temp']
        # Just test it exists
        db_temp.command('ping')
        print("✅ clearvue_data_temp is ready")
        
        client.close()
        print("\n🎉 Database reset complete!")
        print("   Now run: python robust_consumer.py")
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    reset_database()