import pandas as pd
import os
import re
from kafka_utils import KafkaDataProducer


def clean_products():
    # Paths
    input_file = os.path.join("data", "Project Data", "Products.xlsx")

    # Read Excel
    df = pd.read_excel(input_file, dtype=str)

    # Trim spaces
    df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    # LAST_COST: convert to numeric
    df["LAST_COST"] = pd.to_numeric(df["LAST_COST"], errors="coerce").fillna(0)

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("products", df)
    producer.close()

    print("✅ Products data sent to Kafka")


if __name__ == "__main__":
    clean_products()
