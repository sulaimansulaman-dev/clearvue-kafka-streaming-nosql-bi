# reset_environment.py
from kafka import KafkaAdminClient
from kafka.admin import NewTopic
from kafka.errors import UnknownTopicOrPartitionError
import time

def reset_environment():
    print("🔄 RESETTING KAFKA ENVIRONMENT")
    
    # List of all topics we need
    topics = [
        'customers', 'products', 'sales_headers', 'sales_lines',
        'suppliers', 'payment_headers', 'payment_lines',
        'purchase_headers', 'purchase_lines', 'age_analysis',
        'representatives', 'customer_categories', 'customer_regions',
        'product_brands', 'product_ranges', 'product_styles',
        'trans_types'
    ]
    
    try:
        admin = KafkaAdminClient(bootstrap_servers='localhost:9092')
        
        print("Deleting old topics...")
        for topic in topics:
            try:
                admin.delete_topics([topic])
                print(f"  ✅ Deleted: {topic}")
                time.sleep(0.1)
            except UnknownTopicOrPartitionError:
                print(f"  ⚠️ Not found: {topic}")
            except Exception as e:
                print(f"  ❌ Error deleting {topic}: {e}")
        
        time.sleep(2)  # Wait for deletions
        
        admin.close()
        print("\n🎉 Environment reset complete!")
        print("Now run: python simple_mongo_consumer.py")
        
    except Exception as e:
        print(f"❌ Reset failed: {e}")

if __name__ == "__main__":
    reset_environment()