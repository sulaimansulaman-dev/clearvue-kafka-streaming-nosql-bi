import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_purchase_headers():
    input_file = os.path.join("data", "Project Data", "Purchases Headers.xlsx")

    # Read Excel
    df = pd.read_excel(input_file, dtype=str)

    # Trim spaces
    df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    # Convert PURCH_DATE to datetime and remove time
    df["PURCH_DATE"] = pd.to_datetime(df["PURCH_DATE"], errors="coerce").dt.date

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("purchase_headers", df)
    producer.close()

    print("✅ Purchase headers data sent to Kafka")


if __name__ == "__main__":
    clean_purchase_headers()
