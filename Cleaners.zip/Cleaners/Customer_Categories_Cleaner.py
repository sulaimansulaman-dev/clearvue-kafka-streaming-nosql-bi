import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_customer_categories():
    # Input path
    input_file = os.path.join("data", "Project Data", "Customer Categories.xlsx")

    # Read the Excel file
    df = pd.read_excel(input_file, dtype={"CCAT_CODE": str})

    # Strip whitespace
    df = df.map(lambda x: x.strip() if isinstance(x, str) else x)

    # Standardize capitalization and handle unknowns
    df["CCAT_DESC"] = df["CCAT_DESC"].replace("no", "No")

    df = df.drop_duplicates(subset=["CCAT_DESC"], keep="first")

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("customer_categories", df)
    producer.close()

    print("✅ Customer categories data sent to Kafka")


if __name__ == "__main__":
    clean_customer_categories()
