import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_product_brands():
    # Load file
    file_path = os.path.join("data", "Project Data", "Product Brands.xlsx")
    df = pd.read_excel(file_path)

    # Clean PRODBRA_CODE - convert to string, strip whitespace, handle missing values
    df["PRODBRA_CODE"] = (
        pd.to_numeric(df["PRODBRA_CODE"], errors="coerce").fillna(0).astype(int)
    )

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("product_brands", df)
    producer.close()

    print("✅ Product brands data sent to Kafka")


if __name__ == "__main__":
    clean_product_brands()
