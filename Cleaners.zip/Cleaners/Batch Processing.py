# batch_kafka_processor.py
from kafka_utils import KafkaDataProducer
import importlib
import sys
import os

def process_all_cleaners():
    """Run all cleaner scripts and send data to Kafka"""
    cleaner_functions = [
        ('Age_Analysis_Cleaner', 'clean_age_analysis'),
        ('Customer_Categories_Cleaner', 'clean_customer_categories'),
        ('Customer_Cleaner', 'clean_customers'),
        ('Customer_Parameter_Cleaner', 'clean_customer_parameters'),
        ('Customer_Region_Cleaner', 'clean_customer_regions'),
        ('Payment_Header_Cleaner', 'clean_payment_header'),
        ('Payment_Lines_Cleaner', 'clean_payment_lines'),
        ('Product_Brands_Cleaner', 'clean_product_brands'),
        ('Product_Ranges_Cleaner', 'clean_product_ranges'),
        ('Product_Styles_Cleaner', 'clean_product_styles'),
        ('Products_Cleaner', 'clean_products'),
        ('Purchase_Headers_Cleaner', 'clean_purchase_headers'),
        ('Purchase_Lines_Cleaner', 'clean_purchase_lines'),
        ('Representatives_Cleaner', 'clean_representatives'),
        ('Sales_Header_Cleaner', 'clean_sales_header'),
        ('Sales_Line_Cleaner', 'clean_sales_line'),
        ('Supplier_Cleaner', 'clean_suppliers'),
        ('Trans_Type_Cleaner', 'clean_trans_types'),
        ('Product_Brands_Cleaner', 'clean_product_brands')
    ]
    
    for script_name, function_name in cleaner_functions:
        try:
            print(f"\n🔄 Processing {script_name}...")
            
            # Add current directory to Python path
            current_dir = os.path.dirname(os.path.abspath(__file__))
            sys.path.append(current_dir)
            
            # Import and execute the module
            module = importlib.import_module(script_name)
            cleaning_function = getattr(module, function_name)
            cleaning_function()
            
            print(f"✅ Completed {script_name}")
            
        except Exception as e:
            print(f"❌ Failed to process {script_name}: {e}")

if __name__ == "__main__":
    process_all_cleaners()
    print("\n🎉 All data cleaning and Kafka streaming completed!")