import pandas as pd
import os
import re
from kafka_utils import KafkaDataProducer


def clean_product_styles():
    input_file = os.path.join("data", "Project Data", "Products Styles.xlsx")

    # Read Excel
    df = pd.read_excel(input_file, dtype=str)

    # Trim spaces
    df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    # Replace empty cells / NaN with 'N/A'
    df = df.fillna("N/A")

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("product_styles", df)
    producer.close()

    print("✅ Product styles data sent to Kafka")


if __name__ == "__main__":
    clean_product_styles()
