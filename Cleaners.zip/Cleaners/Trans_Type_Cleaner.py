import pandas as pd
import os
from kafka_utils import KafkaDataProducer


def clean_trans_types():
    file_path = os.path.join("data", "Project Data", "Trans Types.xlsx")
    df = pd.read_excel(file_path)

    # Clean TRANSTYPE_CODE
    df["TRANSTYPE_CODE"] = (
        pd.to_numeric(df["TRANSTYPE_CODE"], errors="coerce").fillna(0).astype(int)
    )

    # Send to Kafka
    producer = KafkaDataProducer()
    producer.send_data("trans_types", df)
    producer.close()

    print("✅ Transaction types data sent to Kafka")


if __name__ == "__main__":
    clean_trans_types()
