# kafka_pipeline/config/kafka_config.py
KAFKA_BROKER = "localhost:9092"
