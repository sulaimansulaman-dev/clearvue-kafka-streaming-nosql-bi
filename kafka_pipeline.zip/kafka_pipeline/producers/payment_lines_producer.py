import pandas as pd
import json
from kafka import KafkaProducer
from config.kafka_config import KAFKA_BROKER
import os

def send_data(file_path, topic_name):
    producer = KafkaProducer(
        bootstrap_servers=KAFKA_BROKER,
        value_serializer=lambda v: json.dumps(v, default=str).encode('utf-8')
    )

    df = pd.read_excel(file_path)
    for _, row in df.fillna('').iterrows():
        producer.send(topic_name, row.to_dict())

    producer.flush()
    print(f"✅ Sent {{len(df)}} records from {{file_path}} to '{{topic_name}}'")

if __name__ == "__main__":
    # Adjust relative path when running scripts from the kafka_pipeline folder
    data_root = os.path.join(os.path.dirname(__file__), "..", "..", "Project_Data_Unzipped", "Project Data")
    file_map = {
        "Payment Lines.xlsx": "Payment Lines.xlsx"
    }
    send_data(os.path.join(data_root, file_map["Payment Lines.xlsx"]), "payment_lines_raw")
