Kafka Pipeline (auto-generated)
==================================

Structure:
- config/kafka_config.py : broker config
- producers/*.py         : producers for each excel file (send to topic <name>_raw)
- consumers/*.py         : consumers that read <name>_raw, clean and publish to <name>_cleaned

How to run:
1. Ensure your Kafka broker is reachable at localhost:9092 (adjust config if not).
2. From the kafka_pipeline folder run producers like:
   python3 producers/customer_producer.py
3. Start the consumer in another terminal:
   python3 consumers/customer_consumer.py
4. Repeat for other datasets. Topics follow the pattern: <dataset>_raw and <dataset>_cleaned

Notes:
- Producers read excel files from: Project_Data_Unzipped/Project Data/<Excel file>
- Consumers do simple cleaning; tweak the cleaning logic in consumers/*_consumer.py as needed.
