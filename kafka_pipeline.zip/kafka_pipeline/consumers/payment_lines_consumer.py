import json
from kafka import KafkaConsumer, KafkaProducer
from config.kafka_config import KAFKA_BROKER

def clean_record(record):
    # # Format date fields and remove payments for removed customers
for key in ['CUSTOMER_CODE', 'CUST_CODE', 'CODE']:
    if key in record and str(record.get(key)).strip() in ['599000', '999999']:
        return None
# Try to normalise date-like fields to YYYY-MM-DD if present
for k in list(record.keys()):
    v = record.get(k)
    if isinstance(v, str):
        v_strip = v.strip()
        # naive YYYY/MM/DD or DD/MM/YYYY detection; do not fail on complex cases
        v_strip = v_strip.replace('/', '-')
        record[k] = v_strip
return record

    return record

def consume_and_clean():
    consumer = KafkaConsumer(
        "payment_lines_raw",
        bootstrap_servers=KAFKA_BROKER,
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        auto_offset_reset="earliest",
        enable_auto_commit=True,
        group_id="payment_lines_cleaner"
    )

    producer = KafkaProducer(
        bootstrap_servers=KAFKA_BROKER,
        value_serializer=lambda v: json.dumps(v, default=str).encode("utf-8")
    )

    output_topic = "payment_lines_cleaned"
    print(f"🔍 Listening on '{{payment_lines_raw}}' and sending cleaned records to '{{output_topic}}'")

    for msg in consumer:
        try:
            rec = clean_record(msg.value)
            if rec:
                producer.send(output_topic, rec)
        except Exception as e:
            print('Error cleaning record:', e)

    producer.flush()

if __name__ == "__main__":
    consume_and_clean()
