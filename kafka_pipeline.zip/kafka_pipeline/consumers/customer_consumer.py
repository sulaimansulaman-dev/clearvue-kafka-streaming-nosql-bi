import json
from kafka import KafkaConsumer, KafkaProducer
from config.kafka_config import KAFKA_BROKER

def clean_record(record):
    # # Remove customers with codes 599000 or 999999 (check common code fields)
for key in ['CUSTOMER_CODE', 'CUST_CODE', 'CODE']:
    if key in record and str(record.get(key)).strip() in ['599000', '999999']:
        return None
# Uppercase CCAT_CODE if present
if 'CCAT_CODE' in record and isinstance(record['CCAT_CODE'], str):
    record['CCAT_CODE'] = record['CCAT_CODE'].strip().upper()
# Fix region typos
for k in record:
    if isinstance(record[k], str) and record[k].strip().lower() == 'cons adapro':
        record[k] = 'Cons Adapro'
return record

    return record

def consume_and_clean():
    consumer = KafkaConsumer(
        "customer_raw",
        bootstrap_servers=KAFKA_BROKER,
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        auto_offset_reset="earliest",
        enable_auto_commit=True,
        group_id="customer_cleaner"
    )

    producer = KafkaProducer(
        bootstrap_servers=KAFKA_BROKER,
        value_serializer=lambda v: json.dumps(v, default=str).encode("utf-8")
    )

    output_topic = "customer_cleaned"
    print(f"🔍 Listening on '{{customer_raw}}' and sending cleaned records to '{{output_topic}}'")

    for msg in consumer:
        try:
            rec = clean_record(msg.value)
            if rec:
                producer.send(output_topic, rec)
        except Exception as e:
            print('Error cleaning record:', e)

    producer.flush()

if __name__ == "__main__":
    consume_and_clean()
