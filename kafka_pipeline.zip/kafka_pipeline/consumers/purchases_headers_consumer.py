import json
from kafka import KafkaConsumer, KafkaProducer
from config.kafka_config import KAFKA_BROKER

def clean_record(record):
    # return record
    return record

def consume_and_clean():
    consumer = KafkaConsumer(
        "purchases_headers_raw",
        bootstrap_servers=KAFKA_BROKER,
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        auto_offset_reset="earliest",
        enable_auto_commit=True,
        group_id="purchases_headers_cleaner"
    )

    producer = KafkaProducer(
        bootstrap_servers=KAFKA_BROKER,
        value_serializer=lambda v: json.dumps(v, default=str).encode("utf-8")
    )

    output_topic = "purchases_headers_cleaned"
    print(f"🔍 Listening on '{{purchases_headers_raw}}' and sending cleaned records to '{{output_topic}}'")

    for msg in consumer:
        try:
            rec = clean_record(msg.value)
            if rec:
                producer.send(output_topic, rec)
        except Exception as e:
            print('Error cleaning record:', e)

    producer.flush()

if __name__ == "__main__":
    consume_and_clean()
